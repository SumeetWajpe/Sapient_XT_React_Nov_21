import App from "./App";
import Enzyme, { shallow } from "enzyme";
import Adapter from "enzyme-adapter-react-16";

Enzyme.configure({ adapter: new Adapter() });

describe("state of App component", () => {
  it("will check for state count to be zero", () => {
    let appInstance = shallow(<App />);
    let count = appInstance.state().count;
    expect(count).toBe(0);
  });

  it("should increment the count to 1 : onclick", () => {
    let appInstance = shallow(<App />);
    let btn = appInstance.find("button");
    btn.simulate("click");
    let pText = appInstance.find("p").text();
    expect(pText).toEqual("Count : 1");
  });
});
