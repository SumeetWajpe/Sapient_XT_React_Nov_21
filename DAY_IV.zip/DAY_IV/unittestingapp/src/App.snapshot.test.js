import React from "react";
import App from "./App";
import renderer from "react-test-renderer";

describe("test counter snapshot", () => {
  it("renders correct DOM tree", () => {
    const tree = renderer.create(<App />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
