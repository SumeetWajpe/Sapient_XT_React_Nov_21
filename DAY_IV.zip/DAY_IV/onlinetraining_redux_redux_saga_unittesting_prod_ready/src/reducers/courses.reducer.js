let theCourseId;
let index;
export function courses(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      // console.log("Within Courses reducer !");
      // console.log(action);
      // console.log(defStore);

      theCourseId = action.theCourseId;
      index = defStore.findIndex((c) => c.id === theCourseId);

      return [
        ...defStore.slice(0, index),
        { ...defStore[index], likes: defStore[index].likes + 1 },
        ...defStore.slice(index + 1),
      ];

    case "DELETE_COURSE":
      theCourseId = action.theCourseId;

      index = defStore.findIndex((c) => c.id === theCourseId);

      return [...defStore.slice(0, index), ...defStore.slice(index + 1)];

    case "ADD_COURSE":
      return [...defStore, action.newCourse];

    default:
      return defStore;
  }
}
