import {
  takeEvery,
  call,
  put,
  delay,
  takeLatest,
  retry,
} from "redux-saga/effects";
import axios from "axios";
function* fetch_Posts_Async() {
  // do the side effect  (make the async call)
  try {
    let response = yield call(
      axios.get,
      "https://jsonplaceholder.typicode.com/posts"
    );

    yield put({ type: "FETCH_POSTS", posts: response.data });
  } catch (error) {}
}

function* increment_likes_Async() {
  // async
  yield delay(3000);
  yield put({ type: "INCREMENT_LIKES", theCourseId: 2 });
}

function CallPosts() {
  return axios.get("https://jsonplaceholder.typicode.com/posts");
}

function* retrySaga() {
  try {
    const response = yield retry(3, 5000, CallPosts);
    yield put({ type: "FETCH_POSTS", posts: response.data });
  } catch (error) {
    console.log(error);
  }
}
export function* appSaga() {
  //   yield takeEvery("FETCH_POSTS_ASYNC", fetch_Posts_Async);
  //   yield takeEvery("INCREMENT_LIKES_ASYNC", increment_likes_Async);
  //   yield takeLatest("INCREMENT_LIKES_ASYNC", increment_likes_Async);

  // retry
  yield takeEvery("FETCH_POSTS_ASYNC", retrySaga);
}

// The Problems with REST apis
//1. Kind of hard coded/ not flexible in the structure as well as the number of records
// The endpoints must be existing
