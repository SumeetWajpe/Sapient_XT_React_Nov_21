import React from "react";

export default function Course(props) {
  return (
    <div className="col-md-3">
      <div className="card m-1">
        <img
          height="150px"
          width="200px"
          src={props.coursedetails.imageUrl}
          alt={props.coursedetails.name}
          className="card-img-top"
        />
        <div className="card-body">
          <h5 className="card-title">{props.coursedetails.name}</h5>
          <h6 className="card-text">₹. {props.coursedetails.price}</h6>

          {/* <button
            className="btn btn-primary btn-sm"
            onClick={() => props.IncrementLikes(props.coursedetails.id)}
          >
            <i className="bi bi-hand-thumbs-up"></i> {props.coursedetails.likes}
          </button> */}
          <button
            className="btn btn-primary btn-sm"
            onClick={() => props.IncrementLikesAsync()}
          >
            <i className="bi bi-hand-thumbs-up"></i> {props.coursedetails.likes}
          </button>
          <button
            className="btn btn-danger btn-sm mx-1"
            onClick={() => props.DeleteCourse(props.coursedetails.id)}
          >
            <i className="bi bi-trash"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
