// const INCREMENT_LIKES = "INCREMENT_LIKES";
export function IncrementLikes(theCourseId) {
  return { type: "INCREMENT_LIKES", theCourseId };
}

export function IncrementLikesAsync() {
  return { type: "INCREMENT_LIKES_ASYNC" };
}

export function DeleteCourse(theCourseId) {
  return { type: "DELETE_COURSE", theCourseId };
}

export function AddCourse(newCourse) {
  return { type: "ADD_COURSE", newCourse };
}

export function FetchPosts(posts) {
  return { type: "FETCH_POSTS", posts };
}

export function FetchPostsAsync() {
  return { type: "FETCH_POSTS_ASYNC" };
}

// Using Thunk
// export function FetchPostsAsync() {
//   return (dispatch) => {
//     fetch("https://jsonplaceholder.typicode.com/posts")
//       .then((res) => res.json())
//       .then((posts) => dispatch(FetchPosts(posts)));
//   };
// }

export function DeletePost() {
  return { type: "DELETE_POST" };
}
