import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function PostDetails(props) {
  const { id } = useParams();

  const thePost = props.allPosts.find((p) => p.id == id);
  return (
    <div>
      <h1>Post Details for {id}</h1>
      <h3>User Id : {thePost.userId}</h3>
      <h3>Body : {thePost.body}</h3>
      <h3>Title : {thePost.title}</h3>
      <input
        type="button"
        className="btn btn-primary"
        value="Go Back"
        onClick={() => window.history.back()}
      />
    </div>
  );
}
