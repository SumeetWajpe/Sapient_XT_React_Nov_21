import React, { useEffect } from "react";
import { Link } from "react-router-dom";

export default function Posts(props) {
  useEffect(() => {
    props.FetchPostsAsync();
  }, []);

  let allPosts = props.allPosts.map((post) => (
    <li key={post.id} className="list-group-item">
      <Link to={`/postdetails/${post.id}`}> {post.title} </Link>
    </li>
  ));
  return (
    <div>
      <h2>All Posts</h2>
      {props.allPosts.length > 0 ? (
        <ul className="list-group">{allPosts}</ul>
      ) : (
        <img src="https://miro.medium.com/max/1400/1*CsJ05WEGfunYMLGfsT2sXA.gif" />
      )}
    </div>
  );
}
