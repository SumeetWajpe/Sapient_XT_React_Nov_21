import React from "react";
import Course from "./course.component";

export default function ListOfCourses(props) {
  let coursesToBeCreated = props.allCourses.map((course) => (
    <Course key={course.id} coursedetails={course} {...props} />
  ));
  return (
    <>
      <h1 className="my-5">List of Courses</h1>
      <div className="row">{coursesToBeCreated}</div>
    </>
  );
}
