import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as AllActions from "../actions/actions";
import App from "./App";
function mapStateToProps(store) {
  return {
    allPosts: store.posts,
    allCourses: store.courses,
  };
}

function mapDispatchToProps(dispatcher) {
  return bindActionCreators(AllActions, dispatcher);
}

const MainApp = connect(mapStateToProps, mapDispatchToProps)(App);
export default MainApp;
