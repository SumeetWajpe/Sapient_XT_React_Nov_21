import React from "react";

export default function CoursesWithLikes(props) {
  let coursesWithLikes = props.allCourses.map((c) => (
    <li className="list-group-item" key={c.id}>
      {c.name} - {c.likes}
      <i className="bi bi-hand-thumbs-up"></i>{" "}
    </li>
  ));
  return (
    <div className="col-md-4">
      <h2>Courses With Likes </h2>
      <ul className="list-group">{coursesWithLikes}</ul>
    </div>
  );
}
