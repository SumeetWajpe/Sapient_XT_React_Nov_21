export function posts(defStore = [], action) {
  switch (action.type) {
    case "DELETE_POST":
      console.log("Within posts reducer !");
      console.log(defStore);

      return defStore;

    case "FETCH_POSTS":
      console.log("Within FETCH POSTS");

      return action.posts; // data frm server
    default:
      return defStore;
  }
}
