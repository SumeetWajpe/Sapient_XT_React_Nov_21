import { courses } from "./reducers/courses.reducer";

test("returns initial state", () => {
  expect(courses(undefined, {})).toEqual([]);
});

test("returns added new course state", () => {
  const previousState = [];
  expect(
    courses(previousState, {
      type: "ADD_COURSE",
      newCourse: { id: 6, name: "Fake Course" },
    })
  ).toEqual([{ id: 6, name: "Fake Course" }]);
});
