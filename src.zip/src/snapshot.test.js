import React from "react";
import renderer from "react-test-renderer";
import App from "./App";

describe("snapshot app component", () => {
  it("create snapshot for count as 0", () => {
    const tree = renderer.create(<App />).toJSON();
    expect(tree).toMatchSnapshot();
  });
});
