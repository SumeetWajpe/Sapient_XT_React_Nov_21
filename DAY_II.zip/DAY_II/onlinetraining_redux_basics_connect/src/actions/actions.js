// const INCREMENT_LIKES = "INCREMENT_LIKES";
export function IncrementLikes() {
  return { type: "INCREMENT_LIKES" };
}

export function DeleteCourse() {
  return { type: "DELETE_COURSE" };
}

export function AddCourse() {
  return { type: "ADD_COURSE" };
}

export function DeletePost() {
  return { type: "DELETE_POST" };
}
