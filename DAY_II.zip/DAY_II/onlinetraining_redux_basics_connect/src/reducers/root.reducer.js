import { combineReducers } from "redux";
import { courses } from "./courses.reducer";
import { posts } from "./posts.reducer";

let rootReducer = combineReducers({ courses, posts });

export default rootReducer;
