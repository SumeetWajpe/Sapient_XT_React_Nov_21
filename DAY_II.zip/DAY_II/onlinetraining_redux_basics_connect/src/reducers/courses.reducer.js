export function courses(defStore = [], action) {
  switch (action.type) {
    case "INCREMENT_LIKES":
      console.log("Within Courses reducer !");
      console.log(action);
      return defStore;

    default:
      return defStore;
  }
}
