import React from "react";
import Course from "./course.component";

export default function ListOfCourses(props) {
  let coursesToBeCreated = props.allCourses.map((course) => (
    <Course key={course.id} coursedetails={course} />
  ));
  return <div className="row">{coursesToBeCreated}</div>;
}
