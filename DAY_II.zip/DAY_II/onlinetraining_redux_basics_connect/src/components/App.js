import ListOfCourses from "./listofcourses.component";

function App(props) {
  console.log(props);

  return (
    <div>
      <ListOfCourses allCourses={props.allCourses}></ListOfCourses>
    </div>
  );
}

export default App;
