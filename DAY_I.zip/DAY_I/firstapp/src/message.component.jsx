import "./App.css";
import React from "react";

class Message extends React.Component {
  render() {
    return (
      <>
        <h1> {this.props.message.msg}</h1>
        <img src={this.props.message.image} height="200px" width="200px" />
      </>
    );
  }
}

export default Message;
