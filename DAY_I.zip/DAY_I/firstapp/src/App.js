import "./App.css";
import React from "react";
import Message from "./message.component";

class App extends React.Component {
  messages = [
    {
      msg: "Hello",
      image:
        "https://i.pinimg.com/originals/fb/59/9c/fb599c3e14d13d5d054690ee6eca223a.jpg",
    },
    {
      msg: "Hey",
      image:
        "https://i.pinimg.com/1200x/4d/1d/95/4d1d955c2c8f4498c2843cf07d068927.jpg",
    },
    {
      msg: "Hola",
      image:
        "https://i.pinimg.com/originals/44/79/de/4479de1aed36546d7bc85e75446c7304.jpg",
    },
  ];
  render() {
    let allMsgs = this.messages.map((m) => <Message message={m} />);
    return <>{allMsgs}</>;
  }
}

export default App;
