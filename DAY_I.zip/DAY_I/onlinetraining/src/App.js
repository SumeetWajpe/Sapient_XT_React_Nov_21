import "./App.css";
import Posts from "./components/effect.hook";
import MsgAsFunctional from "./components/functional.component";
import GetPostById from "./components/getpostbyid.component";
import ListOfCourses from "./components/listofcourses.component";
import Counter from "./components/state.hook";
import { BrowserRouter, Switch, Route, Redirect, Link } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      {/* <a href="/">Courses</a> |<a href="/posts">Posts</a> */}
      {/* <Link to="/">Courses</Link> | <Link to="/posts">Posts</Link> */}
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">
            Online Training
          </Link>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link" to="/">
                  Courses
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/posts">
                  Posts
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/postbyid">
                  Get Post By Id
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <Switch>
        <Route path="/" component={ListOfCourses} exact />
        <Route path="/posts" component={Posts}></Route>
        <Route path="/postbyid" component={GetPostById}></Route>

        {/* <Route
            path="**"
            render={() => <h1 style={{ color: "red" }}> Page Not Found</h1>}
          /> */}
        <Route path="**" render={() => <Redirect to="/" />}></Route>
      </Switch>
    </BrowserRouter>
  );
}

export default App;

// <div>
// <ListOfCourses />
// <MsgAsFunctional msg="Hi" />
// <Counter />
// <Posts />
// <GetPostById />
// </div>
