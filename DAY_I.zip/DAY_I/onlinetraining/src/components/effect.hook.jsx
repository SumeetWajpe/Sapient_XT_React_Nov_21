import React, { useEffect, useState } from "react";

export default function Posts() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => res.json())
      .then((posts) => setPosts(posts));
  }, []);

  let allPosts = posts.map((post) => (
    <li key={post.id} className="list-group-item">
      {post.title}
    </li>
  ));
  return (
    <div>
      <h2>All Posts</h2>
      <ul className="list-group">{allPosts}</ul>
    </div>
  );
}
