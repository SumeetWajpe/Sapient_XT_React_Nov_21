import React, { useState } from "react";

// export default function Counter() {
//   let [count, setCount] = useState(10);
//   let [age, setAge] = useState(18);
//   return (
//     <div>
//       <h2>Using State Hook</h2>
//       <p>Current count : {count}</p>
//       <p>Current age : {age}</p>

//       <button className="btn btn-primary" onClick={() => setCount(count + 1)}>
//         Count ++
//       </button>
//       <button className="btn btn-primary mx-1" onClick={() => setAge(age + 1)}>
//         Age ++
//       </button>
//     </div>
//   );
// }

export default function Counter() {
  let [data, setData] = useState({ count: 10, age: 18 });

  return (
    <div>
      <h2>Using State Hook</h2>
      <p>Current count : {data.count}</p>
      <p>Current age : {data.age}</p>

      <button
        className="btn btn-primary"
        onClick={() => setData({ ...data, count: data.count + 1 })}
      >
        Count ++
      </button>
      <button
        className="btn btn-primary mx-1"
        onClick={() => setData({ ...data, age: data.age + 1 })}
      >
        Age ++
      </button>
    </div>
  );
}
