import React from "react";
class Course extends React.Component {
  constructor(props) {
    super(props);
    this.state = { currLikes: this.props.coursedetails.likes };
  }

  IncrementLikes() {
    this.setState({ currLikes: this.state.currLikes + 1 });
  }
  render() {
    return (
      <div className="col-md-3">
        <div className="card m-1">
          <img
            height="150px"
            width="200px"
            src={this.props.coursedetails.imageUrl}
            alt={this.props.coursedetails.name}
            className="card-img-top"
          />
          <div className="card-body">
            <h5 className="card-title">{this.props.coursedetails.name}</h5>
            <h6 className="card-text">₹. {this.props.coursedetails.price}</h6>

            <button
              className="btn btn-primary btn-sm"
              onClick={() => this.IncrementLikes()}
            >
              <i className="bi bi-hand-thumbs-up"></i> {this.state.currLikes}
            </button>
            <button
              className="btn btn-danger btn-sm mx-1"
              onClick={() =>
                this.props.DeleteACourse(this.props.coursedetails.id)
              }
            >
              <i className="bi bi-trash"></i>
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default Course;
