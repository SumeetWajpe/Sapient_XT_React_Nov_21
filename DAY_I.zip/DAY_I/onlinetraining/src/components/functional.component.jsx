// export default function MsgAsFunctional() {
//   return <h2>Hello !</h2>;
// }

// OR

// var MsgAsFunctional = () => {
//   return <h2>Hey !</h2>;
// };

// export default MsgAsFunctional;

// 1. no state
// 2. no lifecycle methods

// 16.8 -> hooks


import React from "react";
export default function MsgAsFunctional(props) {
  return (
    <div>
      <h2>{props.msg}</h2>
    </div>
  );
}
