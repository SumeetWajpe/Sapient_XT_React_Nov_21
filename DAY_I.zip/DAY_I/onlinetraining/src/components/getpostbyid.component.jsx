import React, { useEffect, useState } from "react";

export default function GetPostById() {
  let [postId, setPostId] = useState(1);
  const [post, setPost] = useState({});
  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/posts/" + postId)
      .then((res) => res.json())
      .then((post) => setPost(post));
  }, [postId]);

  return (
    <div>
      <h2>Post By Id</h2>
      <label htmlFor="txtPostId">Enter Post Id here :</label>{" "}
      <input
        type="text"
        id="txtPostId"
        onInput={(e) => setPostId(e.target.value)}
      />
      <h3>{post.title}</h3>
    </div>
  );
}
